# GRPO-Rag — S1 WIP → three sequential-reviewable patches

Controlled execution round. This directory is a **read-only review package**: it
converts the existing LOCAL-PASS working-tree WIP in `/home/avaarg/GRPO-Rag`
into three ordered patches (A / B / C) and re-verifies each one in an isolated
environment. **Nothing was committed, pushed, merged, staged, branched,
worktree-d, reset, stashed, or cleaned anywhere.** No new implementation was
added. The shared repo is byte-for-byte unchanged (see §7).

- Shared repo: `/home/avaarg/GRPO-Rag` (treated read-only)
- Expected / observed HEAD: `f0914adf7d97dc0271f80ba3e1db79dccdd44f99` (branch `main`)
- Delivery dir: `/tmp/grpo-rag-commit-prep-20261011` (symlink `…-current`)

---

## 1. What is in this directory

| Path | Purpose |
|---|---|
| `patches/01-s1-boundary.patch` | A — S1 model-profile authorization boundary + explicit test-stub gate + character evidence budget |
| `patches/02-s1-1-admission.patch` | B — S1.1 provider admission before key acquisition |
| `patches/03-s1-3-intake.patch` | C — S1.3 raw-credential intake refusal + 422 route field whitelist/docs |
| `manifest.json` | Machine-readable record: SHAs, file lists, results, risks |
| `README.md` | This document |
| `logs/` | Raw, unedited command/tool output per group (see `logs/README-logs.md`) |
| `OUTDIR.txt` | Canonical absolute path of this delivery |

All three patches are `git apply`-able and are **meant to be applied in order**
(01 → 02 → 03). Applying all three to a pristine `HEAD` reproduces the current
tracked + untracked (non-ignored) working tree **byte-for-byte** (§4).

---

## 2. Patch inventory

| # | Patch | sha256 | Files | Lines | stage |
|---|---|---|---|---|---|
| 1 | `01-s1-boundary.patch` | `f5438412196e60eb4127a714961868ad8b69620fa121fbb76432e909d334b0d3` | 16 | 1388 | HEAD → A |
| 2 | `02-s1-1-admission.patch` | `5fdd7fa6983de4a0cf7374ee9adbf6992acefbc86f6d1b4f5b258de2fe4689c7` | 11 | 915 | A → B |
| 3 | `03-s1-3-intake.patch` | `9527418e2c8ed31eecdacd9736c1c7149cb8f0fbdc8348b2f4a13294f7312699` | 20 | 1489 | B → C |

Each patch text encodes exactly the file set listed in `manifest.json` under
`patches[].modifies/adds/deletes`.

### A — `01-s1-boundary.patch`
Modifies: `docs/architecture.md`, `docs/project-progress.md`,
`packages/model-gateway/src/ragos/model_gateway/{router,key_pool,profiles}.py`,
`packages/retrieval/src/ragos/retrieval/gateway.py`.
Adds: `docs/opencode-s1-task.md`, the S1 validation bundle
`docs/validation/s1-model-authorization-2026-10-10/*`, and
`tests/test_gateway_evidence_budget.py`, `tests/test_model_profile_authorization.py`,
`tests/test_provider_capability.py`.

### B — `02-s1-1-admission.patch`
Modifies: `packages/model-gateway/src/ragos/model_gateway/{router,key_pool}.py`.
Adds: `docs/s1-1-implementation-report.md`,
`docs/validation/s1-1-gateway-hardening/*`, `tests/test_provider_admission.py`.

### C — `03-s1-3-intake.patch`
Modifies: `apps/api-server/src/ragos_api/errors.py`,
`apps/api-server/src/ragos_api/routes/model_center.py`,
`packages/storage/src/ragos/storage/repositories/model_gateway.py`,
`tests/test_model_center_route.py`.
Adds: `docs/s1-3-implementation-report.md`,
`docs/validation/s1-3-secret-intake/*`, `tests/test_secret_intake.py`.

---

## 3. Provenance of each stage (why these bytes)

- **A** — the exact A bytes were **not** present as a git object/stash/reflog/dangling
  blob. They were recovered from an authoritative, git-ignored **post-A build
  snapshot** at `build/lib/`, which differs from `HEAD` in exactly these 4 files:
  `router.py`, `key_pool.py`, `profiles.py`, `retrieval/gateway.py`. Every A-stage
  source/test SHA matches the frozen record
  `docs/validation/s1-model-authorization-2026-10-10/manifest.json`:

  | file | sha256 | matches frozen S1 manifest |
  |---|---|---|
  | `packages/model-gateway/…/router.py` | `fefa4d1a…c69a` | ✅ |
  | `packages/model-gateway/…/key_pool.py` | `451e043b…5b13d` | ✅ |
  | `packages/model-gateway/…/profiles.py` | `db464dd3…721c1a` | ✅ |
  | `packages/retrieval/…/gateway.py` | `7b1cd325…4cd12c` | ✅ |
  | `tests/test_model_profile_authorization.py` | `4c469b5c…26d961` | ✅ |
  | `tests/test_provider_capability.py` | `698d5cfd…1061933` | ✅ |
  | `tests/test_gateway_evidence_budget.py` | `e76f49c7…5ca1111` | ✅ |

- **B** — taken from the shared working tree; the B-stage sources match
  `docs/validation/s1-1-gateway-hardening/source-digest.txt`
  (`router.py 244dc7fd…`, `key_pool.py a0afade5…`, `test_provider_admission.py 6e94f95f…`).
- **C** — taken from the shared working tree; the C-stage sources match
  `docs/validation/s1-3-secret-intake/source-digest-rework.txt`
  (`errors.py 923a73ee…`, `routes/model_center.py 27495373…`,
  `storage/repositories/model_gateway.py ebdf9c3e…`, `test_secret_intake.py 24ee80a5…`,
  `test_model_center_route.py 23d38db3…`). The **C tree is byte-identical to the
  shared working tree (286/286)**.

---

## 4. Composition proof (applying 01 → 02 → 03)

Method (`logs/31-composition-proof.txt`, generated by `work/verify_final.py`):

1. `git archive HEAD | tar -x` into a pristine dir (no `.git`).
2. `git apply --check` + `git apply` for 01, then 02, then 03.
3. Compare every `git ls-files -co --exclude-standard` path (286 files) to the
   shared working tree by sha256.

Result:

```
shared_files=286 applied_files=286
missing=0 extra=0 mismatch=0
COMPOSITION_BYTE_IDENTICAL=True
```

Patch 03 prints a benign `warning: 16 lines add whitespace errors` — the raw
validation evidence logs intentionally retain tool-output trailing whitespace.
This does not affect the applied bytes.

To reproduce from a pristine checkout:

```bash
git archive HEAD | tar -x -C /tmp/pristine && cd /tmp/pristine
git apply --check /tmp/grpo-rag-commit-prep-20261011/patches/01-s1-boundary.patch
git apply         /tmp/grpo-rag-commit-prep-20261011/patches/01-s1-boundary.patch
git apply         /tmp/grpo-rag-commit-prep-20261011/patches/02-s1-1-admission.patch
git apply         /tmp/grpo-rag-commit-prep-20261011/patches/03-s1-3-intake.patch
```

---

## 5. Independent verification (isolated, full suite)

Environment per group: fresh **uv venv, Python 3.11.17** (uv `0.12.23`),
dependencies from a **frozen export** run *inside the candidate tree*
(`uv export --frozen --extra dev --no-hashes --no-emit-project --all-packages`),
then a **non-editable** install (`uv pip install --no-deps --no-editable <tree>`),
**no `PYTHONPATH`**. Installed `site-packages` copies were sha256-compared back to
the candidate sources before running tests (`INSTALLED_SHA_OK=True`, 170 `.py`
files each). Full suite: `pytest -q -p no:cacheprovider` from the candidate dir.

| Group | Tree | installed-sha | pytest | exit | targeted ruff |
|---|---|---|---|---|---|
| baseline | `HEAD` | ✅ 170 py | **754 passed, 21 skipped** | 0 | All checks passed! |
| A | HEAD+01 | ✅ 170 py | **778 passed, 21 skipped** | 0 | All checks passed! |
| B | HEAD+01+02 | ✅ 170 py | **791 passed, 21 skipped** | 0 | All checks passed! |
| C | HEAD+01+02+03 | ✅ 170 py | **832 passed, 21 skipped** | 0 | All checks passed! |

Frozen dependency content is identical across all four groups
(`d22e9136…be68` after stripping the per-group `uv export -o <path>` header);
the lock files differ only by that header line.

- **Skipped (not PASS): 21 tests**, all with the same reason —
  `RAGOS_TEST_PG_DSN must explicitly identify a disposable local PostgreSQL DB`:
  `tests/test_index_integration.py` (11) + `tests/test_storage_integration.py` (10).
  Identical set in baseline/A/B/C.
- **Whole-repo ruff** reports a constant **117 pre-existing errors** in every
  tree (116× E501 + 1× I001): `infra/migrations/versions/0001_pg_scaffold.py`
  (79× E501 + 1× I001 line 8), `0004_model_gateway.py` (6× E501),
  `0005_page_anchored_eval.py` (31× E501). Pre-existing, **not fixed** (fixing
  lint was out of scope). See `logs/*/24-ruff-whole-repo-concise.txt` (identical
  across groups).
- Targeted ruff on each group's own changed/new Python files passes in all groups.

### Historical vs. this round
Historical validation numbers remain recorded **as history only** and were not
rewritten. This round ran its own full suites independently:

| | historical (recorded earlier) | this round (independent) |
|---|---|---|
| S1 selected regression / baseline | 120 / 11 | A full: 778 passed, 21 skipped |
| S1.1 full suite | 791 passed, 21 skipped | B full: 791 passed, 21 skipped (reproduced) |
| S1.3 rework full suite | 832 passed, 21 skipped | C full: 832 passed, 21 skipped (reproduced) |
| S1.3 review targeted | 98 passed | — |

**NOT RUN is never recorded as PASS.**

---

## 6. Scope / explicitly NOT RUN

- No real provider (Qwen / OpenAI) calls; **no network model dispatch**.
- No PostgreSQL / Redis / Qdrant service; the 21 PG integration tests are
  **skipped, not passed**.
- No browser / UI journey; no migration execution.
- No S1.4 / R1 or any new implementation.
- Historical validation artefacts were not rewritten.

---

## 7. Shared repo — zero changes

Recorded before and after this round (identical):

- HEAD `f0914adf7d97dc0271f80ba3e1db79dccdd44f99`, branch `main`.
- `git status` (tracked + untracked) and `git diff --stat` unchanged.
- 286 tracked + untracked (non-ignored) files; combined sha256-list digest
  `3a885e0fe922d7e4b8f0f7604001a961e72ddc1e5a78697f5ab29d3a67aea609` — unchanged.
- `git diff --check` exit 0 (no whitespace errors introduced in the tree).

All test runs happened in copies under `/tmp`; the shared tree was never written.

---

## 8. Suggested commit messages (suggestions only — nothing was committed)

Apply in order; each is a self-contained, reviewable step.

```
01  feat(s1): enforce model-profile authorization boundary + explicit stub gate + char evidence budget

    - model gateway router enforces profile authorization before dispatch
    - test-only stub path is gated behind an explicit flag (no prod implicit stub)
    - evidence budget expressed in characters with a frozen-budget test
    - recovery: exact A bytes from the frozen S1 manifest (source SHA verified)
```

```
02  feat(s1.1): require provider admission before key acquisition

    - provider capability/admission decided before any key-pool acquisition
    - router + key_pool adjusted; provider admission test added
```

```
03  feat(s1.3): refuse raw credential intake; whitelist model-center 422 fields

    - API rejects raw credentials at the model-center boundary (secret intake)
    - 422 response surfaces a whitelisted field set only
    - storage repository + route + docs updated accordingly
```

---

## 9. Remaining risks / rollback

- **A provenance**: A was reconstructed from the ignored `build/lib` snapshot
  (no git object/stash/reflog contained the bytes); it is verified by sha256
  against the frozen S1 manifest, but the snapshot is the only copy of the
  original A bytes.
- **B / C** encode the shared working tree state exactly. If the shared tree is
  later advanced independently, these patches will need a rebase.
- Raw evidence logs intentionally keep trailing whitespace; patch 03 apply warns
  about it (cosmetic).
- Pre-existing whole-repo ruff failures (migrations) are listed, not fixed.
- **Rollback**: these patches are additive to the review process only — apply
  them in a throwaway checkout, never in the shared tree. To undo, discard the
  checkout. No shared-repo state exists to revert.

---

## 10. Reproduce this package

Internal scripts (kept for transparency, not required to review):

```bash
cd /tmp/grpo-rag-commit-prep-20261011
python3 work/build_trees.py        # rebuild A/B/C trees
python3 work/generate_patches.py   # regenerate patches 01/02/03
python3 work/verify_final.py       # composition proof (HEAD -> 01 -> 02 -> 03)
python3 work/make_artifacts.py     # regenerate manifest.json
# per-group isolated full-suite verification:
work/verify_group.sh <baseline|A|B|C> work/trees/<baseline|A|B|C>
```

Freeze notice: `uv.lock` / `pyproject.toml` were never modified; the frozen
export is read-only against the candidate's own copy.

---

## 11. Independent reviewer artifacts (Codex-authored, not the author)

The controller/reviewer (Codex) produced its own independent checks in this
same directory. These are **reviewer** outputs, recorded here for completeness:

| Path | Contents |
|---|---|
| `codex-review.md` | Reviewer narrative: independent composition proof + targeted tests |
| `codex-composition-review.json` | Reviewer's machine-readable composition proof (all 3 `apply --check` true, 286 files byte-identical, patch SHAs) |
| `codex-apply-q3ey32fp/` | Reviewer's apply/verify tree (scratch) |

Reviewer targeted-test results (separate from this author's full suites; both
point the same way): A 35 passed, B 42 passed, C 98 passed. Reviewer did not
re-run the full suites; the full-suite numbers in §5 are the author's evidence.
