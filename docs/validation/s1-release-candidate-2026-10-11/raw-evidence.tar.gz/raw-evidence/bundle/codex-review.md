# Codex independent patch preparation review

Scope: prepare reviewable patches and evidence only. No commit, push, merge, stage, branch/worktree creation, shared implementation changes, S1.4 or R1 execution.

Independent composition proof: `codex-composition-review.json`. Starting from a fresh archive of HEAD `f0914adf7d97dc0271f80ba3e1db79dccdd44f99`, all three patches passed `git apply --check` and applied in order. A matched all seven historical manifest source digests; B matched its frozen router/key_pool/test digests; C reproduced all 286 shared tracked/untracked nonignored files byte-for-byte, with no extras.

Independent targeted tests used each stage's frozen, noneditable installed environment and ran from that stage's isolated tree:

| Stage | Files | Actual result |
|---|---|---|
| A | model_gateway, model_profile_authorization, provider_capability, gateway_evidence_budget | 35 passed in 0.33s |
| B | provider_admission, model_gateway, model_profile_authorization, provider_capability | 42 passed in 0.72s |
| C | secret_intake, model_center_route plus B files and gateway_evidence_budget | 98 passed in 1.76s |

Command prefix for stage X: `work/envs/X/venv/bin/python -m pytest -q -p no:cacheprovider`, working directory `work/trees/X`, followed by the corresponding `tests/test_*.py` files. Every final test command exited 0.

OpenCode Big Pickle's current full-suite execution is separate author evidence: baseline 754, A 778, B 791, C 832 passed; each skipped 21 PostgreSQL integration tests because the disposable PG DSN was absent. Reviewer did not independently rerun the full suites. Whole-tree Ruff has the same 117 existing findings (116 E501 and one I001) in all stages; targeted Ruff passed. Do not interpret the existing lint failure as a new regression or as a passed gate.

The shared repository's 286 file digests matched the pre-task baseline after preparation. Historical validation logs are retained unchanged and are not relabeled as new execution. This is a local patch-preparation review, not production readiness or merge approval. Real providers, PostgreSQL/RLS and Qdrant Server remain outside these checks.
